package antikb;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

public class AntiKBScreen extends Screen {
    private final Screen parent;

    public AntiKBScreen(Screen parent) {
        super(Component.literal("AntiKB"));
        this.parent = parent;
    }

    private static Component label() {
        return Component.literal("Anti-Knockback: " + (AntiKB.enabled ? "ON" : "OFF"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;
        addRenderableWidget(Button.builder(label(), b -> {
            AntiKB.enabled = !AntiKB.enabled;
            AntiKB.save();
            b.setMessage(label());
        }).bounds(cx - 100, cy - 10, 200, 20).build());
        addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose())
                .bounds(cx - 100, cy + 20, 200, 20).build());
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}

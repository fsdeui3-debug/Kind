package antikb;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class AntiKB implements ClientModInitializer {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("antikb.json");

    public static boolean enabled = true;

    private static class Data { boolean enabled = true; }

    @Override
    public void onInitializeClient() {
        try {
            if (Files.exists(FILE)) {
                enabled = GSON.fromJson(Files.readString(FILE), Data.class).enabled;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        try {
            Data d = new Data();
            d.enabled = enabled;
            Files.writeString(FILE, GSON.toJson(d));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

package antikb.mixin;

import antikb.AntiKB;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public class ClientPacketListenerMixin {
    // Cancels server velocity (knockback) packets aimed at the local player.
    @Inject(method = "handleSetEntityMotion", at = @At("HEAD"), cancellable = true)
    private void antikb$cancelKnockback(ClientboundSetEntityMotionPacket packet, CallbackInfo ci) {
        if (!AntiKB.enabled) return;
        var player = Minecraft.getInstance().player;
        if (player != null && packet.id() == player.getId()) {
            ci.cancel();
        }
    }
}
